// This file is for debugging purposes - run it in a browser console
console.log("UserHistory in localStorage:", JSON.parse(localStorage.getItem('userHistory') || '{}'));
